$regfile = "m8adef.dat"
$crystal = 8000000
Config Adc = Single , Prescaler = Auto , Reference = Avcc
Enable Interrupts
Config Portc.0 = Input
Config Portc.2 = Output
Dim Insw As Bit
Dim Vale As Word
Do
  If Pinc.0 = 0 And Insw = 1 Then
     Insw = 0
     Portc.2 = 0
 End If
   If Pinc.0 = 1 And Insw = 0 Then
   Portc.2 = 1
    Insw = 1
    Vale = Getadc(1)
    Print Vale
   End If


Loop

